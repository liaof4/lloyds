﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using LloydsXMLProperty;
using System.Xml.Serialization;
using System.IO;
using System.Data;
using static LloydsDataService.DataService;
using System.Xml.Linq;
using System.Net.Http;
using System.Xml;
using System.Linq;

namespace LloydsDataService
{
    public class Processor
    {

        string ConnectionString = ConfigurationManager.ConnectionStrings["CBLReport"].ConnectionString;
        string CoverHolderNumber;

        public string GenerateLloydsBatchApp(string QueryCriteria)
        {
            DataService dsv = new DataService();
            List<PolicyInquiryDetail> PolicyList = new List<PolicyInquiryDetail>();

            string[] param = QueryCriteria.Split('-');
            string PolicyType = param[0];
            string IssuingCompany = param[1];
            string PPECode = param[3].Replace("_","-");
            string SSRAction = String.Join<char>(",", param[4]);
            string SSRStatus = param[5];
            string UpdateDate = param[6];
            string UpdateBy = param[7];
            string BatchNumber = param[9];
            string ReportUser = param[10];

            var s = param[2];
            var list = Enumerable
                .Range(0, s.Length / 3)
                .Select(ctr => s.Substring(ctr * 3, 3));
            string LineStatus = string.Join(",", list);

            PolicyList = dsv.GetPolicySourceList(PolicyType, IssuingCompany, LineStatus, PPECode, 
                  SSRAction, SSRStatus, UpdateDate, UpdateBy, CoverHolderNumber);

            PolicyTransactions pols = new PolicyTransactions();
            pols.BatchNumberAttribute = BatchNumber;
            pols.CoverHolderNumber = param[8];

            int i = 0;
            List<PolicyTransaction> txns = new List<PolicyTransaction>();
            foreach (PolicyInquiryDetail lst in PolicyList)
            {
                if (i == 2) break;
                PolicyTransaction tx = new PolicyTransaction();
                if (lst.ServiceSummaryAction == "N")
                {
                    tx = GetLloydsNewData(lst.UniqLineImage);
                }else{
                    tx = GetLloydsRenewData(lst.UniqLineImage);
                }
                txns.Add(tx);
                i++;
            }

            pols.PolicyTransactionItems = txns;
            return GetLloydsXML(pols);
        }

        public string GenerateLloydsSingleApp(string QueryCriteria)
        {

            string[] param = QueryCriteria.Split('-');
            string SSRAction = param[0];
            string PolicyNumber = param[1];
            int UniqLineImage = Int32.Parse(param[2]);
            string BatchNumber = param[3];
            string ReportUser = param[4];

            List<PolicyInquiryDetail> PolicyList = new List<PolicyInquiryDetail>();
            //string CoverHolderNumber = PolicyNumber.Substring(0, 2) == "AB" ? "2646" : "2647";

            PolicyTransactions pols = new PolicyTransactions();
            pols.BatchNumberAttribute = BatchNumber;

            List<PolicyTransaction> txns = new List<PolicyTransaction>();
            PolicyTransaction tx = new PolicyTransaction();

            if (SSRAction == "N")
            {
                tx = GetLloydsNewData(UniqLineImage);
            }
            else
            {
                tx = GetLloydsRenewData(UniqLineImage);
            }
 
            txns.Add(tx);
            pols.CoverHolderNumber = CoverHolderNumber;
            pols.PolicyTransactionItems = txns;
            return GetLloydsXML(pols);
        }

        public PolicyTransaction GetLloydsNewData(int UniqLineImage)
        {

            SqlConnection conn = new SqlConnection(ConnectionString);
            PolicyTransaction pol = new PolicyTransaction();
            PolicyCommercialRecord rec = new LloydsXMLProperty.PolicyCommercialRecord();

            PolicyNumberField pn = new PolicyNumberField();
            EffectiveDateField eff = new EffectiveDateField();
            ExpiryDateField exp = new ExpiryDateField();
            BinderFlagField bfl = new BinderFlagField();
            SubscriptionTypeCodeField sty = new SubscriptionTypeCodeField();
            TotalPremiumAmountField prem = new TotalPremiumAmountField();
            PaymentMethodCodeField pcd = new PaymentMethodCodeField();
            AnalysisDescriptionRefField ade = new AnalysisDescriptionRefField();
            BindingAuthorityContractNbrField bac = new BindingAuthorityContractNbrField();
            CoverageListTypeCodeField clt = new CoverageListTypeCodeField();

            DataService dsv = new DataService();
            PolicyInfo pif = new PolicyInfo();

            pif = dsv.GetPolicyInfo(UniqLineImage);
            CoverHolderNumber = pif.CoverHolderNumber;
            pol.TransactionNumberAttribute = dsv.GetTransactionId("WebAPI", pif.PolicyNumber, "N", "P").ToString();
            
            pn.value = pif.PolicyNumber;
            rec.PolicyNumber = pn;

            eff.value = pif.EffectiveDate;
            rec.EffectiveDate = eff;

            exp.value = pif.ExpirationDate;
            rec.ExpiryDate = exp;

            bfl.value = pif.BinderFlag;
            rec.BinderFlag = bfl;

            sty.value = pif.SubscriptionTypeCode;
            rec.SubscriptionTypeCode = sty;

            prem.value = pif.AnnualizedPremium;
            rec.TotalPremiumAmount = prem;

            pcd.value = pif.PaymentMethodCode;
            rec.PaymentMethodCode = pcd;

            rec.AnalysisDescriptionRef = ade;
            ade.value = pif.AnalysisDescriptionRef;
            bac.value = pif.UMRReferenceNumber;
            rec.BindingAuthorityContractNbr = bac;
            clt.value = pif.CoverageListTypeCode;
            rec.CoverageListTypeCode = clt;

            // Get Policy Units Information
            List<InsuredCommercialUnits> irecs = new List<InsuredCommercialUnits>();
            InsuredCommercialUnitsRecord insu = new InsuredCommercialUnitsRecord();

            List<InsuredProperty> ipr = new List<InsuredProperty>();
            ipr = dsv.GetPropertyList(UniqLineImage);

            List<CHCommissionSchedule> chs = new List<CHCommissionSchedule>();
            chs = dsv.GetCHolderCommissionSched(UniqLineImage);

            List<InsuranceCoverage> inscov = new List<InsuranceCoverage>();
            chs = dsv.GetCHolderCommissionSched(UniqLineImage);

            foreach (InsuredProperty ipd in ipr)
            {
                InsuredCommercialUnits irec = new InsuredCommercialUnits();
                CHolderCommissionSchedule sched = new CHolderCommissionSchedule();

                UnitNumberField uni = new UnitNumberField();
                uni.value = ipd.UnitNumber;
                irec.UnitNumber = uni;

                irec.EffectiveDate = eff;

                irec.ExpiryDate = exp;

                /* ------- Remove, not found in sample XML file ---------
                InsuredRiskNameField rsk = new InsuredRiskNameField();
                rsk.value = "??Unknown??";
                irec.InsuredRiskName = rsk;
                ---------------------------------------------------------  */

                // 00000010 ======================== Start Commission Schedule ========================
                List<CHolderCommission> comms = new List<CHolderCommission>();

                foreach (CHCommissionSchedule chc in chs)
                {
                    CHolderCommission comm = new CHolderCommission();
                    BindingAuthorityContractNbrField con = new BindingAuthorityContractNbrField();
                    AnalysisDescriptionRefField adr = new AnalysisDescriptionRefField();
                    CHolderCommissionPercentField pct = new CHolderCommissionPercentField();

                    con.value = chc.UMRReferenceNumber.Trim();
                    adr.value = chc.AnalysisDescriptionRef;
                    pct.value = chc.CommissionPercent.ToString();

                    comm.BindingAuthorityContractNbr = con;
                    comm.AnalysisDescriptionRef = adr;
                    comm.CHolderCommissionPercent = pct;
                    comms.Add(comm);
                }

                if (comms.Count != 0)
                {

                    sched.HolderCommission = comms;
                    irec.CommissionSchedule = sched;

                    // -------------------- Address --------------------
                    AddressRecord add = new AddressRecord();
                    CountryCodeField coun = new CountryCodeField();
                    AddressLine1Field adr1 = new AddressLine1Field();
                    AddressLine2Field adr2 = new AddressLine2Field();
                    CityField city = new CityField();
                    PostalCodeField zip = new PostalCodeField();
                    ProvinceCodeField prov = new ProvinceCodeField();

                    coun.value = ipd.CountryCode;
                    adr1.value = ipd.Address1;
                    adr2.value = ipd.Address2;
                    city.value = ipd.City;
                    zip.value = ipd.PostalCode;
                    prov.value = ipd.ProvinceCode;

                    add.CountryCode = coun;
                    add.AddressLine1 = adr1;
                    add.AddressLine2 = adr2;
                    add.City = city;
                    add.PostalCode = zip;
                    add.ProvinceCode = prov;

                    irec.Address = add;
                }

                // -------------------- Industry Classification Code --------------------
                if (ipd.IndustryClassificationCode != "")
                {
                    IndustryClassificationCodeField icc = new IndustryClassificationCodeField();
                    icc.value = ipd.IndustryClassificationCode;
                    irec.IndustryClassificationCode = icc;
                }

                if (ipd.YearBuilt != 0)
                {
                    YearBuiltField yrb = new YearBuiltField();
                    yrb.value = ipd.YearBuilt;
                    irec.YearBuilt = yrb;
                }

                if (ipd.Construction != "")
                {
                    ConstructionField cns = new ConstructionField();
                    cns.value = ipd.Construction;
                    irec.Construction = cns;
                }

                if (ipd.Sprinklered != "")
                {
                    SprinkleredField sfl = new SprinkleredField();
                    sfl.value = ipd.Sprinklered;
                    irec.Sprinklered = sfl;
                }

                if (ipd.NumberOfStories != 0)
                {
                    NumberOfStoriesField sto = new NumberOfStoriesField();
                    sto.value = ipd.NumberOfStories;
                    irec.NumberOfStories = sto;
                }

                if (ipd.IsEarthquakeCovered != "")
                {
                    IsEarthquakeCoveredField equ = new IsEarthquakeCoveredField();
                    equ.value = ipd.IsEarthquakeCovered;
                    irec.IsEarthquakeCovered = equ;
                }

                if (ipd.IsFloodCovered != "")
                {
                    IsFloodCoveredField flo = new IsFloodCoveredField();
                    flo.value = ipd.IsFloodCovered;
                    irec.IsFloodCovered = flo;
                }

                // 00000030 ======================== Start Of Coverages ========================

                CommercialCoveragesRecord ccov = new CommercialCoveragesRecord();
                List<CommercialCoverageRecord> cfl = new List<CommercialCoverageRecord>();
                List<InsuranceCoverage> iCoverage = new List<InsuranceCoverage>();
                iCoverage = dsv.GetInsuranceCoverage(UniqLineImage);

                foreach (InsuranceCoverage cv in iCoverage)
                {
                    if (ipd.UnitNumber == cv.LocationNo)
                    {
                        CommercialCoverageRecord cov = new CommercialCoverageRecord();
                        CoverageTypeField ctf = new CoverageTypeField();
                        DeductibleTypeField cty = new DeductibleTypeField();
                        EffectiveDateField cef = new EffectiveDateField();
                        ExpiryDateField cex = new ExpiryDateField();
                        DeductibleAmountField ded = new DeductibleAmountField();
                        PremiumAmountField prm = new PremiumAmountField();
                        PremiumParticipationScheduleRecord ppr = new PremiumParticipationScheduleRecord();
                        ClaimsMadeCoverageFlagField clm = new ClaimsMadeCoverageFlagField();
                        ExtendedReportPeriodFlagField exr = new ExtendedReportPeriodFlagField();
                        RetroactiveDateField rad = new RetroactiveDateField();
                        CoverageLimitField clf = new CoverageLimitField();

                        ctf.value = cv.CoverageTypeCode;
                        cty.value = cv.DeductibleTypeCode;
                        cef.value = eff.value;
                        cex.value = exp.value;
                        ded.value = cv.DeductibleAmount;
                        clf.value = cv.CoverageLimit;
                        prm.value = cv.PremiumAmount;
                        clm.value = cv.ClaimsMadeFlag;
                        exr.value = cv.ExtendedReportPeriodFlag;

                        if (cv.RetroactiveDate != null)
                        {
                            rad.value = (DateTime)cv.RetroactiveDate;
                            cov.RetroactiveDate = rad;
                        }

                        cov.CoverageType = ctf;
                        cov.DeductibleAmount = ded;
                        cov.DeductibleType = cty;
                        cov.EffectiveDate = cef;
                        cov.ExpiryDate = cex;
                        cov.PremiumAmount = prm;
                        cov.ClaimsMadeCoverageFlag = clm;
                        cov.ExtendedReportPeriodFlag = exr;
                        cov.CoverageLimit = clf;

                        if (cv.SectionCode.Substring(0, 1) == "L")
                        {
                            TurnOverOrFeesField tof = new TurnOverOrFeesField();
                            OccupationField occ = new OccupationField();
                            tof.value = cv.TurnoverOrFees;
                            occ.value = cv.Occupation;
                            cov.TurnOverOrFees = tof;
                            cov.Occupation = occ;

                            ExposureTypeCodeField ext = new ExposureTypeCodeField();
                            TotalExposureAmountField tea = new TotalExposureAmountField();
                            ext.value = cv.ExposureTypeCode;
                            tea.value = cv.TotalExposureAmount;
                            cov.ExposureTypeCode = ext;
                            cov.TotalExposureAmount = tea;
                        }

                        //if (pif.IssuingProvinceCode == "ON" && cv.SectionCode.Substring(0,1) == "L"){ 
                        //}

                        // ------- Premium Participation section
                        PremiumParticipationScheduleRecord pps = new PremiumParticipationScheduleRecord();
                        List<PremiumParticipationRecord> lpprec = new List<PremiumParticipationRecord>();

                        foreach (PremiumParticipation pprec in cv.PremiumParticipationSched.PremiumParticipations)
                        {
                            if (pprec.UMRReferenceNumber != "")
                            {
                                PremiumParticipationRecord pmr = new PremiumParticipationRecord();

                                BindingAuthorityContractNbrField pbac = new BindingAuthorityContractNbrField();
                                AnalysisDescriptionRefField padf = new AnalysisDescriptionRefField();
                                ParticipationPercentField ppct = new ParticipationPercentField();
                                PremiumParticipationAmountField ppaf = new PremiumParticipationAmountField();

                                pbac.value = pprec.UMRReferenceNumber;
                                padf.value = pprec.AnalysisDescriptionRef;
                                ppct.value = pprec.ParticipationPercent;
                                ppaf.value = pprec.PremiumParticipationAmount;

                                pmr.BindingAuthorityContractNbr = pbac;
                                pmr.AnalysisDescriptionRef = padf;
                                pmr.ParticipationPercent = ppct;
                                pmr.PremiumParticipationAmount = ppaf;
                                lpprec.Add(pmr);
                            }
                        }

                        List<OtherPremiumParticipationRecord> olpprec = new List<OtherPremiumParticipationRecord>();

                        foreach (PremiumParticipation pprec in cv.PremiumParticipationSched.PremiumParticipations)
                        {
                            if (pprec.UMRReferenceNumber == "")
                            {
                                OtherPremiumParticipationRecord opmr = new OtherPremiumParticipationRecord();

                                OtherParticipationPercentField oppct = new OtherParticipationPercentField();
                                OtherPremiumParticipationAmountField oppaf = new OtherPremiumParticipationAmountField();

                                oppct.value = pprec.ParticipationPercent;
                                oppaf.value = pprec.PremiumParticipationAmount;

                                opmr.OtherParticipationPercent = oppct;
                                opmr.OtherPremiumParticipationAmount = oppaf;
                                olpprec.Add(opmr);
                            }
                        }

                        pps.PremiumParticipationRecords = lpprec;
                        pps.OtherPremiumParticipationRecords = olpprec;
                        cov.PremiumParticipationSchedule = pps;
                        cfl.Add(cov);

                    }
                }

                ccov.CommercialCoverages = cfl;
                irec.CommercialCoverage = ccov;

                irecs.Add(irec);
                insu.CommercialUnitsCreateRecord = irecs;
                rec.InsuredCommercialUnits = insu;

            }

            // 00000050 -------------- START OF POLICY PARTY DATA ------------------
            PolicyPartiesRecord pspr = new PolicyPartiesRecord();
            PolicyPartyRecord pppr = new PolicyPartyRecord();
            CompanyRecord pcpy = new CompanyRecord();
            CompanyNameField pcnf = new CompanyNameField();
            AddressRecord padd = new AddressRecord();
            CountryCodeField pcoun = new CountryCodeField();
            AddressLine1Field padr1 = new AddressLine1Field();
            AddressLine2Field padr2 = new AddressLine2Field();
            CityField pcity = new CityField();
            PostalCodeField pzip = new PostalCodeField();
            ProvinceCodeField pprov = new ProvinceCodeField();

            pcoun.value = pif.CountryCode;
            padr1.value = pif.Address1;
            padr2.value = pif.Address2;
            pcity.value = pif.City;
            pzip.value = pif.PostalCode;
            pprov.value = pif.ProvinceCode;

            pppr.PartyRoleTypeCodeAttr = "INSURED";
            pcnf.value = pif.AccountName;

            padd.CountryCode = pcoun;
            padd.AddressLine1 = padr1;
            padd.AddressLine2 = padr2;
            padd.City = pcity;
            padd.ProvinceCode = pprov;
            padd.PostalCode = pzip;
            pcpy.CompanyName = pcnf;
            pcpy.Address = padd;

            pppr.Company = pcpy;
            pspr.PolicyParty = pppr;
            rec.PolicyParties = pspr;

            // 00000050 -------------- END OF POLICY PARTY DATA ------------------

            PolicyNewTransaction newTran = new PolicyNewTransaction();
            newTran.PolicyCommercialCreateRecord = rec;
            pol.PolicyCreateNewTransaction = newTran;

            return pol;

        }
        public PolicyTransaction GetLloydsRenewData(int UniqLineImage)
        {
                
            SqlConnection conn = new SqlConnection(ConnectionString);
            PolicyTransaction pol = new PolicyTransaction();
            PolicyCommercialRecord rec = new LloydsXMLProperty.PolicyCommercialRecord();

            PolicyNumberField pn = new PolicyNumberField();
            EffectiveDateField eff = new EffectiveDateField();
            ExpiryDateField exp = new ExpiryDateField();
            BinderFlagField bfl = new BinderFlagField();
            SubscriptionTypeCodeField sty = new SubscriptionTypeCodeField();
            TotalPremiumAmountField prem = new TotalPremiumAmountField();
            PaymentMethodCodeField pcd = new PaymentMethodCodeField();
            AnalysisDescriptionRefField ade = new AnalysisDescriptionRefField();
            BindingAuthorityContractNbrField bac = new BindingAuthorityContractNbrField();
            CoverageListTypeCodeField clt = new CoverageListTypeCodeField();

            DataService dsv = new DataService();
            PolicyInfo pif = new PolicyInfo();

            pif = dsv.GetPolicyInfo(UniqLineImage);
            CoverHolderNumber = pif.CoverHolderNumber;
            pol.TransactionNumberAttribute = dsv.GetTransactionId("WebAPI",pif.PolicyNumber,"R","P").ToString();

            pn.value = pif.PolicyNumber;
            rec.PolicyNumber = pn;

            eff.value = pif.EffectiveDate;
            rec.EffectiveDate = eff;

            exp.value = pif.ExpirationDate;
            rec.ExpiryDate = exp;

            bfl.value = pif.BinderFlag;
            rec.BinderFlag = bfl;

            sty.value = pif.SubscriptionTypeCode;
            rec.SubscriptionTypeCode = sty;

            prem.value = pif.AnnualizedPremium;
            rec.TotalPremiumAmount = prem;

            pcd.value = pif.PaymentMethodCode;
            rec.PaymentMethodCode = pcd;

            rec.AnalysisDescriptionRef = ade;
            ade.value = pif.AnalysisDescriptionRef;
            bac.value = pif.UMRReferenceNumber;
            rec.BindingAuthorityContractNbr = bac;
            clt.value = pif.CoverageListTypeCode;
            rec.CoverageListTypeCode = clt;

            // Get Policy Units Information
            List<InsuredCommercialUnits> irecs = new List<InsuredCommercialUnits>();
            InsuredCommercialUnitsRecord insu = new InsuredCommercialUnitsRecord();

            List<InsuredProperty> ipr = new List<InsuredProperty>();
            ipr = dsv.GetPropertyList(UniqLineImage);

            List<CHCommissionSchedule> chs = new List<CHCommissionSchedule>();
            chs = dsv.GetCHolderCommissionSched(UniqLineImage);

            List<InsuranceCoverage> inscov = new List<InsuranceCoverage>();
            chs = dsv.GetCHolderCommissionSched(UniqLineImage);

            foreach (InsuredProperty ipd in ipr)
            {
                InsuredCommercialUnits irec = new InsuredCommercialUnits();
                CHolderCommissionSchedule sched = new CHolderCommissionSchedule();

                UnitNumberField uni = new UnitNumberField();
                uni.value = ipd.UnitNumber;
                irec.UnitNumber = uni;

                irec.EffectiveDate = eff;

                irec.ExpiryDate = exp;

                /* ------- Remove, not found in sample XML file ---------
                InsuredRiskNameField rsk = new InsuredRiskNameField();
                rsk.value = "??Unknown??";
                irec.InsuredRiskName = rsk;
                ---------------------------------------------------------  */

                // 00000010 ======================== Start Commission Schedule ========================
                List<CHolderCommission> comms = new List<CHolderCommission>();

                foreach (CHCommissionSchedule chc in chs)
                {
                    CHolderCommission comm = new CHolderCommission();
                    BindingAuthorityContractNbrField con = new BindingAuthorityContractNbrField();
                    AnalysisDescriptionRefField adr = new AnalysisDescriptionRefField();
                    CHolderCommissionPercentField pct = new CHolderCommissionPercentField();

                    con.value = chc.UMRReferenceNumber.Trim();
                    adr.value = chc.AnalysisDescriptionRef;
                    pct.value = chc.CommissionPercent.ToString();

                    comm.BindingAuthorityContractNbr = con;
                    comm.AnalysisDescriptionRef = adr;
                    comm.CHolderCommissionPercent = pct;
                    comms.Add(comm);
                }

                if (comms.Count != 0)
                {

                    sched.HolderCommission = comms;
                    irec.CommissionSchedule = sched;

                    // -------------------- Address --------------------
                    AddressRecord add = new AddressRecord();
                    CountryCodeField coun = new CountryCodeField();
                    AddressLine1Field adr1 = new AddressLine1Field();
                    AddressLine2Field adr2 = new AddressLine2Field();
                    CityField city = new CityField();
                    PostalCodeField zip = new PostalCodeField();
                    ProvinceCodeField prov = new ProvinceCodeField();

                    coun.value = ipd.CountryCode;
                    adr1.value = ipd.Address1;
                    adr2.value = ipd.Address2;
                    city.value = ipd.City;
                    zip.value = ipd.PostalCode;
                    prov.value = ipd.ProvinceCode;

                    add.CountryCode = coun;
                    add.AddressLine1 = adr1;
                    add.AddressLine2 = adr2;
                    add.City = city;
                    add.PostalCode = zip;
                    add.ProvinceCode = prov;

                    irec.Address = add;
                }

                // -------------------- Industry Classification Code --------------------
                if (ipd.IndustryClassificationCode != "")
                {
                    IndustryClassificationCodeField icc = new IndustryClassificationCodeField();
                    icc.value = ipd.IndustryClassificationCode;
                    irec.IndustryClassificationCode = icc;
                }

                if (ipd.YearBuilt != 0) { 
                    YearBuiltField yrb = new YearBuiltField();
                    yrb.value = ipd.YearBuilt;
                    irec.YearBuilt = yrb;
                }

                if(ipd.Construction != "") { 
                    ConstructionField cns = new ConstructionField();
                    cns.value = ipd.Construction;
                    irec.Construction = cns;
                }

                if (ipd.Sprinklered != "")
                {
                    SprinkleredField sfl = new SprinkleredField();
                    sfl.value = ipd.Sprinklered;
                    irec.Sprinklered = sfl;
                }

                if (ipd.NumberOfStories != 0)
                {
                    NumberOfStoriesField sto = new NumberOfStoriesField();
                    sto.value = ipd.NumberOfStories;
                    irec.NumberOfStories = sto;
                }

                if (ipd.IsEarthquakeCovered != "")
                {
                    IsEarthquakeCoveredField equ = new IsEarthquakeCoveredField();
                    equ.value = ipd.IsEarthquakeCovered;
                    irec.IsEarthquakeCovered = equ;
                }

                if (ipd.IsFloodCovered != "")
                {
                    IsFloodCoveredField flo = new IsFloodCoveredField();
                    flo.value = ipd.IsFloodCovered;
                    irec.IsFloodCovered = flo;
                }

                // 00000030 ======================== Start Of Coverages ========================

                CommercialCoveragesRecord ccov = new CommercialCoveragesRecord();
                List<CommercialCoverageRecord> cfl = new List<CommercialCoverageRecord>();
                List<InsuranceCoverage> iCoverage = new List<InsuranceCoverage>();
                iCoverage = dsv.GetInsuranceCoverage(UniqLineImage);

                foreach (InsuranceCoverage cv in iCoverage)
                {
                    if (ipd.UnitNumber == cv.LocationNo)
                    {
                        CommercialCoverageRecord cov = new CommercialCoverageRecord();
                        CoverageTypeField ctf = new CoverageTypeField();
                        DeductibleTypeField cty = new DeductibleTypeField();
                        EffectiveDateField cef = new EffectiveDateField();
                        ExpiryDateField cex = new ExpiryDateField();
                        DeductibleAmountField ded = new DeductibleAmountField();
                        PremiumAmountField prm = new PremiumAmountField();
                        PremiumParticipationScheduleRecord ppr = new PremiumParticipationScheduleRecord();
                        ClaimsMadeCoverageFlagField clm = new ClaimsMadeCoverageFlagField();
                        ExtendedReportPeriodFlagField exr = new ExtendedReportPeriodFlagField();
                        RetroactiveDateField rad = new RetroactiveDateField();
                        CoverageLimitField clf = new CoverageLimitField();

                        ctf.value = cv.CoverageTypeCode;
                        cty.value = cv.DeductibleTypeCode;
                        cef.value = eff.value;
                        cex.value = exp.value;
                        ded.value = cv.DeductibleAmount;
                        clf.value = cv.CoverageLimit;
                        prm.value = cv.PremiumAmount;
                        clm.value = cv.ClaimsMadeFlag;
                        exr.value = cv.ExtendedReportPeriodFlag;

                        if (cv.RetroactiveDate != null) { 
                            rad.value = (DateTime) cv.RetroactiveDate;
                            cov.RetroactiveDate = rad;
                        }

                        cov.CoverageType = ctf;
                        cov.DeductibleAmount = ded;
                        cov.DeductibleType = cty;
                        cov.EffectiveDate = cef;
                        cov.ExpiryDate = cex;
                        cov.PremiumAmount = prm;
                        cov.ClaimsMadeCoverageFlag = clm;
                        cov.ExtendedReportPeriodFlag = exr;
                        cov.CoverageLimit = clf;

                        if (cv.SectionCode.Substring(0, 1) == "L")
                        {
                            TurnOverOrFeesField tof = new TurnOverOrFeesField();
                            OccupationField occ = new OccupationField();
                            tof.value = cv.TurnoverOrFees;
                            occ.value = cv.Occupation;
                            cov.TurnOverOrFees = tof;
                            cov.Occupation = occ;

                            ExposureTypeCodeField ext = new ExposureTypeCodeField();
                            TotalExposureAmountField tea = new TotalExposureAmountField();
                            ext.value = cv.ExposureTypeCode;
                            tea.value = cv.TotalExposureAmount;
                            cov.ExposureTypeCode = ext;
                            cov.TotalExposureAmount = tea;
                        }

                        // ------- Premium Participation section
                        PremiumParticipationScheduleRecord pps = new PremiumParticipationScheduleRecord();
                        List<PremiumParticipationRecord> lpprec = new List<PremiumParticipationRecord>();

                        foreach (PremiumParticipation pprec in cv.PremiumParticipationSched.PremiumParticipations)
                        {
                            if (pprec.UMRReferenceNumber != "")
                            {
                                PremiumParticipationRecord pmr = new PremiumParticipationRecord();

                                BindingAuthorityContractNbrField pbac = new BindingAuthorityContractNbrField();
                                AnalysisDescriptionRefField padf = new AnalysisDescriptionRefField();
                                ParticipationPercentField ppct = new ParticipationPercentField();
                                PremiumParticipationAmountField ppaf = new PremiumParticipationAmountField();

                                pbac.value = pprec.UMRReferenceNumber;
                                padf.value = pprec.AnalysisDescriptionRef;
                                ppct.value = pprec.ParticipationPercent;
                                ppaf.value = pprec.PremiumParticipationAmount;

                                pmr.BindingAuthorityContractNbr = pbac;
                                pmr.AnalysisDescriptionRef = padf;
                                pmr.ParticipationPercent = ppct;
                                pmr.PremiumParticipationAmount = ppaf;
                                lpprec.Add(pmr);
                            }
                        }
                        pps.PremiumParticipationRecords = lpprec;
                        //cov.PremiumParticipationSchedule = pps;

                        //OtherPremiumParticipationScheduleRecord opps = new OtherPremiumParticipationScheduleRecord();
                        List<OtherPremiumParticipationRecord> olpprec = new List<OtherPremiumParticipationRecord>();

                        foreach (PremiumParticipation pprec in cv.PremiumParticipationSched.PremiumParticipations)
                        {
                            if (pprec.UMRReferenceNumber == "")
                            {
                                OtherPremiumParticipationRecord opmr = new OtherPremiumParticipationRecord();

                                OtherParticipationPercentField oppct = new OtherParticipationPercentField();
                                OtherPremiumParticipationAmountField oppaf = new OtherPremiumParticipationAmountField();

                                oppct.value = pprec.ParticipationPercent;
                                oppaf.value = pprec.PremiumParticipationAmount;

                                opmr.OtherParticipationPercent = oppct;
                                opmr.OtherPremiumParticipationAmount = oppaf;
                                olpprec.Add(opmr);
                           }
                        }

                        pps.OtherPremiumParticipationRecords = olpprec;
                        cov.PremiumParticipationSchedule = pps;
                        cfl.Add(cov);

                    }
                }

                ccov.CommercialCoverages = cfl;
                irec.CommercialCoverage = ccov;

                irecs.Add(irec);
                insu.CommercialUnitsCreateRecord = irecs;
                rec.InsuredCommercialUnits = insu;

            }

            // 00000050 -------------- START OF POLICY PARTY DATA ------------------
            PolicyPartiesRecord pspr = new PolicyPartiesRecord();
            PolicyPartyRecord pppr = new PolicyPartyRecord();
            CompanyRecord pcpy = new CompanyRecord();
            CompanyNameField pcnf = new CompanyNameField();
            AddressRecord padd = new AddressRecord();
            CountryCodeField pcoun = new CountryCodeField();
            AddressLine1Field padr1 = new AddressLine1Field();
            AddressLine2Field padr2 = new AddressLine2Field();
            CityField pcity = new CityField();
            PostalCodeField pzip = new PostalCodeField();
            ProvinceCodeField pprov = new ProvinceCodeField();

            pcoun.value = pif.CountryCode;
            padr1.value = pif.Address1;
            padr2.value = pif.Address2;
            pcity.value = pif.City;
            pzip.value = pif.PostalCode;
            pprov.value = pif.ProvinceCode;

            pppr.PartyRoleTypeCodeAttr = "INSURED";
            pcnf.value = pif.AccountName;

            padd.CountryCode = pcoun;
            padd.AddressLine1 = padr1;
            padd.AddressLine2 = padr2;
            padd.City = pcity;
            padd.ProvinceCode = pprov;
            padd.PostalCode = pzip;
            pcpy.CompanyName = pcnf;
            pcpy.Address = padd;

            pppr.Company = pcpy;
            pspr.PolicyParty = pppr;
            rec.PolicyParties = pspr;

            // 00000050 -------------- END OF POLICY PARTY DATA ------------------

            PolicyRenewTransaction renew = new PolicyRenewTransaction();
            renew.PolicyCommercialCreateRecord = rec;
            pol.PolicyCreateRenewTransaction = renew;

            return pol;

        }

        public static void SerializeXml(PolicyTransactions pol)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(PolicyTransactions));

            var path = "C:\\Utils\\Lloyds\\LloydsOut.xml";
            System.IO.FileStream file = System.IO.File.Create(path);
            serializer.Serialize(file, pol);

        }

        public class StringWriterWithEncoding : StringWriter
        {
            public StringWriterWithEncoding(StringBuilder sb, Encoding encoding)
                : base(sb)
            {
                this.m_Encoding = encoding;
            }
            private readonly Encoding m_Encoding;
            public override Encoding Encoding
            {
                get
                {
                    return this.m_Encoding;
                }
            }
        }
        public static string GetLloydsXML(PolicyTransactions ptx)
        {
            string xml;
            XmlSerializer serializer = new XmlSerializer(typeof(PolicyTransactions));

            StringBuilder sb = new StringBuilder();
            StringWriterWithEncoding stringWriter = new StringWriterWithEncoding(sb, Encoding.UTF8);

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.CloseOutput = true;
            XmlWriter writer = XmlWriter.Create(stringWriter, settings);

            serializer.Serialize(writer, ptx);
            xml = sb.ToString();
            writer.Close();

            return xml;

        }
    }
}

