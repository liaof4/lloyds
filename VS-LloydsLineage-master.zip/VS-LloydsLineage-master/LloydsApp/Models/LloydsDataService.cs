﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using LloydsXMLProperty;
using System.Xml.Serialization;
using System.IO;
using System.Data;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Web;

namespace LloydsDataService
{
    public class DataService
    {

        string ConnectionString = ConfigurationManager.ConnectionStrings["CBLReport"].ConnectionString;

        public PolicyInfo GetPolicyInfo(int UniqLineImage)
        {
            PolicyInfo pol = new PolicyInfo();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand("uspLloydsGetPolicyInfo", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@UniqLineImage", UniqLineImage);
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr != null)
                        {
                            while (rdr.Read())
                            {
                                pol.AccountName = rdr["ClientName"].ToString();
                                pol.Address1 = rdr["Address1"].ToString();
                                pol.Address2 = rdr["Address2"].ToString();
                                pol.City = rdr["City"].ToString();
                                pol.PostalCode = rdr["PostalCode"].ToString().Trim();
                                pol.ProvinceCode = rdr["CdStateCode"].ToString().Trim();
                                pol.CountryCode = rdr["CdCountryCode"].ToString().Substring(0, 2);
                                pol.PolicyNumber = rdr["PolicyNumber"].ToString();
                                pol.IssuingProvinceCode = rdr["IssuingProvinceCode"].ToString();
                                pol.EffectiveDate = DateTime.Parse(rdr["EffectiveDate"].ToString());
                                pol.ExpirationDate = DateTime.Parse(rdr["ExpirationDate"].ToString());
                                pol.BinderFlag = rdr["BinderFlag"].ToString();
                                pol.SubscriptionTypeCode = rdr["SubscriptionTypeCode"].ToString();
                                pol.AnnualizedPremium = Double.Parse(rdr["AnnualizedPremium"].ToString());
                                pol.PaymentMethodCode = rdr["PaymentMethodCode"].ToString();
                                pol.CoverHolderNumber = rdr["CoverHolderNumber"].ToString();
                                pol.AnalysisDescriptionRef = rdr["AnalysisDescriptionRef"].ToString();
                                pol.UMRReferenceNumber = rdr["UMRreferenceNumber"].ToString();
                                pol.CoverageListTypeCode = rdr["CoverageListTypeCode"].ToString();
                            }
                        }
                    }
                }
            }

            return pol;
        }

        public List<InsuredProperty> GetPropertyList(int UniqLineImage)
        {
            List<InsuredProperty> ipl = new List<InsuredProperty>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand("uspLloydsGetPropertyList", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@UniqLineImage", UniqLineImage);
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr != null)
                        {
                            while (rdr.Read())
                            {
                                InsuredProperty inp = new InsuredProperty();
                                inp.Address1 = rdr["Address1"].ToString();
                                inp.Address2 = rdr["Address2"].ToString();
                                inp.City = rdr["City"].ToString();
                                inp.PostalCode = rdr["PostalCode"].ToString().Trim();
                                inp.ProvinceCode = rdr["CdStateCode"].ToString().Trim();
                                inp.CountryCode = rdr["CdCountryCode"].ToString().Substring(0,2);
                                inp.UnitNumber = rdr["LocationNumber"].ToString();
                                inp.IndustryClassificationCode = rdr["IndustryClassCode"].ToString();
                                inp.YearBuilt = rdr["YearBuilt"].ToString() == "" ? 0 : Int32.Parse(rdr["YearBuilt"].ToString());
                                inp.Construction = rdr["Construction"].ToString();
                                inp.Sprinklered = rdr["Sprinklered"].ToString();
                                inp.NumberOfStories = rdr["NumberOfStories"].ToString() == "" ? 0 : Double.Parse(rdr["NumberOfStories"].ToString());
                                inp.IsEarthquakeCovered = rdr["IsEarthquakeCovered"].ToString();
                                inp.IsFloodCovered = rdr["IsFloodCovered"].ToString();
                                ipl.Add(inp);
                            }
                        }
                    } // reader closed and disposed up here
                } // command disposed here
            } //con
            return ipl;
        }

        public List<CHCommissionSchedule> GetCHolderCommissionSched(int UniqLineImage)
        {
            List<CHCommissionSchedule> ccs = new List<CHCommissionSchedule>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand("uspLloydsGetCHolderCommission", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@UniqLineImage", UniqLineImage);
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr != null)
                        {
                            while (rdr.Read())
                            {
                                ccs.Add(new CHCommissionSchedule
                                {
                                    UMRReferenceNumber = rdr["UMRReferenceNumber"].ToString(),
                                    AnalysisDescriptionRef = rdr["AnalysisDescriptionRef"].ToString(),
                                    CommissionPercent = rdr["CommissionPercent"].ToString() == "" ? 0 : Double.Parse(rdr["CommissionPercent"].ToString())
                                });
                            }
                        }
                    }
                }
            }
            return ccs;
        }

        public List<SubscribingCompany> GetSubcribingCompany(int UniqLineImage)
        {
            List<SubscribingCompany> cpy = new List<SubscribingCompany>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand("uspLloydsGetSubscribingCompany", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@UniqLineImage", UniqLineImage);
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr != null)
                        {
                            while (rdr.Read())
                            {
                                cpy.Add(new SubscribingCompany
                                {
                                    SectionCode = rdr["SectionCode"].ToString(),
                                    IssuingCompanyCode = rdr["IssuingCompanyCode"].ToString(),
                                    UMRReferenceNumber = rdr["UMRReferenceNumber"].ToString(),
                                    AnalysisDescriptionRef = rdr["AnalysisDescriptionRef"].ToString(),
                                    InsuredPercent = rdr["PercentageInsured"].ToString() == "" ? 0 : Double.Parse(rdr["PercentageInsured"].ToString()),
                                    Premium = rdr["Premium"].ToString() == "" ? 0 : Double.Parse(rdr["Premium"].ToString())
                                });
                            }
                        }
                    }
                }
            }
            return cpy;
        }

        public List<InsuranceCoverage> GetInsuranceCoverage(int UniqLineImage)
        {
            List<InsuranceCoverage> icr = new List<InsuranceCoverage>();
            List<SubscribingCompany> scy = new List<SubscribingCompany>();

            scy = GetSubcribingCompany(UniqLineImage);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand("uspLloydsGetCoverage", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@UniqLineImage", UniqLineImage);
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr != null)
                        {
                            while (rdr.Read())
                            {
                                InsuranceCoverage icc = new InsuranceCoverage();

                                icc.IssuingCompanyCode = rdr["IssuingCompanyCode"].ToString();
                                icc.IssuingProvinceCode = rdr["IssuingProvinceCode"].ToString();
                                icc.SectionCode = rdr["SectionCode"].ToString();
                                icc.LocationNo = rdr["LocationNo"].ToString();
                                icc.CoverageTypeCode = rdr["CoverageCode"].ToString();
                                icc.EffectiveDate = DateTime.Parse(rdr["EffectiveDate"].ToString());
                                icc.ExpirationDate = DateTime.Parse(rdr["ExpirationDate"].ToString());
                                icc.DeductibleTypeCode = rdr["DeductibleTypeCode"].ToString();
                                icc.DeductibleAmount = rdr["Deductible"].ToString() == "" ? 0 : Double.Parse(rdr["Deductible"].ToString());
                                icc.PremiumAmount = rdr["Premium"].ToString() == "" ? 0 : Double.Parse(rdr["Premium"].ToString());
                                icc.ClaimsMadeFlag = rdr["ClaimsMadeFlag"].ToString();
                                icc.ExtendedReportPeriodFlag = rdr["ExtendedReportPeriodFlag"].ToString();
                                icc.RetroactiveDate = rdr["RetroactiveDate"] == DBNull.Value ? (DateTime?) null : (DateTime) rdr["RetroactiveDate"];
                                icc.ExposureTypeCode = rdr["ExposureTypeCode"].ToString();
                                icc.TotalExposureAmount = Double.Parse(rdr["TotalExposureAmount"].ToString());
                                icc.CoverageLimit = rdr["Limit"].ToString() == "" ? 0 : Double.Parse(rdr["Limit"].ToString());
                                icc.TurnoverOrFees = Double.Parse(rdr["TurnoverOrFees"].ToString());
                                icc.Occupation = rdr["Occupation"].ToString(); ;

                                PremiumParticipationSchedule pps = new PremiumParticipationSchedule();
                                List<PremiumParticipation> ppart = new List<PremiumParticipation>();

                                ppart = GetPremiumParticipationSchedule(UniqLineImage, icc.SectionCode, icc.PremiumAmount);
                                //foreach (SubscribingCompany ssc in scy)
                                //{
                                //    if(icc.SectionCode == ssc.SectionCode) && icc.IssuingCompanyCode == ssc.IssuingCompanyCode)
                                //    {
                                //        PremiumParticipation ppc = new PremiumParticipation();
                                //        ppc.UMRReferenceNumber = ssc.UMRReferenceNumber;
                                //        ppc.AnalysisDescriptionRef = ssc.AnalysisDescriptionRef;
                                //        ppc.ParticipationPercent = ssc.InsuredPercent;
                                //        ppc.PremiumParticipationAmount = ssc.Premium;
                                //        ppart.Add(ppc);
                                //    }
                                //}

                                pps.PremiumParticipations = ppart;
                                icc.PremiumParticipationSched = pps;
                                icr.Add(icc);
                            }
                        }
                    }
                }
            }
            return icr;
        }

        public List<PremiumParticipation> GetPremiumParticipationSchedule(int UniqLineImage, string SectionCode, Double PremiumAmount)
        {
            List<PremiumParticipation> pps = new List<PremiumParticipation>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand("uspLloydsGetPremiumParticipation", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@UniqLineImage", UniqLineImage);
                    cmd.Parameters.AddWithValue("@SectionCode", SectionCode);
                    cmd.Parameters.AddWithValue("@PremiumAmount", PremiumAmount);
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr != null)
                        {
                            while (rdr.Read())
                            {
                                pps.Add(new PremiumParticipation
                                {
                                    UMRReferenceNumber = rdr["UMRReferenceNumber"].ToString(),
                                    AnalysisDescriptionRef = rdr["AnalysisDescriptionRef"].ToString(),
                                    ParticipationPercent = rdr["PercentageInsured"].ToString() == "" ? 0 : Double.Parse(rdr["PercentageInsured"].ToString()),
                                    PremiumParticipationAmount = rdr["Premium"].ToString() == "" ? 0 : Double.Parse(rdr["Premium"].ToString())
                                });
                            }
                        }
                    }
                }
            }
            return pps;
        }

        public int GetLineImageByPolicy(string PolicyNumber, string PolicyType)
        {
            int UniqLineImage = -1;

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("uspGetLineImageByPolicy", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@PolicyNumber", PolicyNumber);
                    cmd.Parameters.AddWithValue("@PolicyType", PolicyType);
                    cmd.Parameters.Add("@UniqLineImage", SqlDbType.Int);

                    cmd.Parameters["@UniqLineImage"].Direction = ParameterDirection.Output;

                    try
                    {
                        connection.Open();
                        int i = cmd.ExecuteNonQuery();
                        UniqLineImage = Convert.ToInt32(cmd.Parameters["@UniqLineImage"].Value);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }

            return UniqLineImage;
        }

        public int GetTransactionId(string UserId, string PolicyNumber, string EventType, string EventStatus)
        {
            int LogId = -1;

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("uspLloydsLogEvent", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.Parameters.AddWithValue("@PolicyNumber", PolicyNumber);
                    cmd.Parameters.AddWithValue("@EventType", EventType);
                    cmd.Parameters.AddWithValue("@EventStatus", EventStatus);
                    cmd.Parameters.Add("@LogId", SqlDbType.Int);

                    cmd.Parameters["@LogId"].Direction = ParameterDirection.Output;

                    try
                    {
                        connection.Open();
                        int i = cmd.ExecuteNonQuery();
                        LogId = Convert.ToInt32(cmd.Parameters["@LogId"].Value);
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }

            return LogId;
        }

        public void UpdateLog(int LogId, string EventStatus, string LogMesssage)
        {

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("uspLloydsLogUpdate", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@LogId", LogId);
                    cmd.Parameters.AddWithValue("@EventStatus", EventStatus);
                    cmd.Parameters.AddWithValue("@LogMessage", LogMesssage);

                    try
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }

        public string GetXMLData(string xml, string AttributeName)
        {
            string AttributeValue = string.Empty;
            XmlTextReader reader = null;
            try
            {
                //Load the reader with the XML file.
                reader = new XmlTextReader(new StringReader(xml));

                //Read the attribute.
                reader.MoveToContent();
                AttributeValue = reader.GetAttribute(AttributeName);
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
            return AttributeValue;
        }

        public List<PolicyInquiryDetail> GetPolicySourceList(string PolicyType, string IssuingCompany,
                string LineStatus, string PPECode, string SSRAction, string SSRStatus, 
                string UpdateDate, string UpdateBy, string CoverHolderNumber)
        {

            List<PolicyInquiryDetail> pid = new List<PolicyInquiryDetail>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("uspLloydsGetPolicyList", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 100;
                    cmd.Parameters.AddWithValue("@PolicyType", PolicyType);
                    cmd.Parameters.AddWithValue("@IssuingCompany", IssuingCompany);
                    cmd.Parameters.AddWithValue("@LineStatus", LineStatus);
                    cmd.Parameters.AddWithValue("@PPECode", PPECode);
                    cmd.Parameters.AddWithValue("@SSRAction", SSRAction);
                    cmd.Parameters.AddWithValue("@SSRStatus", SSRStatus);
                    cmd.Parameters.AddWithValue("@UpdateDate", UpdateDate);
                    cmd.Parameters.AddWithValue("@UpdateBy", UpdateBy);
                    cmd.Parameters.AddWithValue("@CoverHolderNumber", CoverHolderNumber);
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr != null)
                        {
                            while (rdr.Read())
                            {
                                pid.Add(new PolicyInquiryDetail
                                {
                                    UniqLineImage = Int32.Parse(rdr["UniqLineImage"].ToString()),
                                    ServiceSummaryAction = rdr["Action"].ToString()
                                });
                            }
                        }
                    }
                }
            }

            return pid;
        }

        public string ValidateXML(string XmlDoc, string XsdFile)
        {
            string path = HttpRuntime.AppDomainAppPath;
            string errorMessage = string.Empty;
            bool errors = false;

            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add("", path + XsdFile);

            XDocument xdoc = XDocument.Load(new StringReader(XmlDoc));
            xdoc.Validate(schemas, (o, e) =>
            {
                errorMessage += e.Message;
                errors = true;
            });

            return errors == true ? errorMessage : "OK";
        }

        public class PolicyInfo
        {
            public string AccountName { get; set; }
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public string City { get; set; }
            public string PostalCode { get; set; }
            public string ProvinceCode { get; set; }
            public string CountryCode { get; set; }
            public string PolicyNumber { get; set; }
            public string IssuingProvinceCode { get; set; }
            public DateTime EffectiveDate { get; set; }
            public DateTime ExpirationDate { get; set; }
            public string BinderFlag { get; set; }
            public string SubscriptionTypeCode { get; set; }
            public double AnnualizedPremium { get; set; }
            public string PaymentMethodCode { get; set; }
            public string CoverHolderNumber { get; set; }
            public string AnalysisDescriptionRef { get; set; }
            public string UMRReferenceNumber { get; set; }
            public string CoverageListTypeCode { get; set; }
        }

        public class InsuredProperty
        {
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public string City { get; set; }
            public string PostalCode { get; set; }
            public string ProvinceCode { get; set; }
            public string CountryCode { get; set; }
            public string UnitNumber { get; set; }
            public string IndustryClassificationCode { get; set; }
            public int YearBuilt { get; set; }
            public string Construction { get; set; }
            public string Sprinklered { get; set; }
            public double NumberOfStories { get; set; }
            public string IsEarthquakeCovered { get; set; }
            public string IsFloodCovered{ get; set; }
    }


        public class CHCommissionSchedule
        {
            public string SectionCode { get; set; }
            public string UMRReferenceNumber { get; set; }
            public string AnalysisDescriptionRef { get; set; }
            public double CommissionPercent { get; set; }
        }

        public class SubscribingCompany
        {
            public string SectionCode { get; set; }
            public string IssuingCompanyCode { get; set; }
            public string UMRReferenceNumber { get; set; }
            public string AnalysisDescriptionRef { get; set; }
            public double InsuredPercent { get; set; }
            public double Premium { get; set; }
        }

        public class InsuranceCoverage
        {
            public string IssuingCompanyCode { get; set; }
            public string IssuingProvinceCode { get; set; }
            public string SectionCode { get; set; }
            public string LocationNo { get; set; }
            public string CoverageTypeCode { get; set; }
            public DateTime EffectiveDate { get; set; }
            public DateTime ExpirationDate { get; set; }
            public string DeductibleTypeCode { get; set; }
            public double DeductibleAmount { get; set; }
            public double PremiumAmount { get; set; }
            public PremiumParticipationSchedule PremiumParticipationSched { get; set; }
            public string ClaimsMadeFlag { get; set; }
            public string ExtendedReportPeriodFlag { get; set; }
            public DateTime? RetroactiveDate { get; set; }
            public string ExposureTypeCode { get; set; }
            public double TotalExposureAmount { get; set; }
            public double CoverageLimit { get; set; }
            public double TurnoverOrFees { get; set; }
            public string Occupation { get; set; }

        }

        public class PremiumParticipationSchedule
        {
            public List<PremiumParticipation> PremiumParticipations;
            public List<OtherPremiumParticipation> OtherPremiumParticipations;
        }

        public class PremiumParticipation
        {
            public string UMRReferenceNumber { get; set; }
            public string AnalysisDescriptionRef { get; set; }
            public double ParticipationPercent { get; set; }
            public double PremiumParticipationAmount { get; set; }
        }

        public class OtherPremiumParticipation
        {
            public double OtherParticipationPercent { get; set; }
            public double OtherPremiumParticipationAmount { get; set; }
        }

        public class PolicyInquiryDetail
        {
            public int UniqLineImage { get; set; }
            public string ServiceSummaryAction { get; set; }
 
        }
    }
}