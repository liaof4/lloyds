﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LloydsXMLProperty
{
    [System.Xml.Serialization.XmlRootAttribute("policy-transactions", Namespace = "", IsNullable = false)]
    public class PolicyTransactions
    {

        [System.Xml.Serialization.XmlAttributeAttribute("majorVersion", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public int MajorVersion = 9;

        [System.Xml.Serialization.XmlAttributeAttribute("minorVersion", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public int MinorVersion = 2;

        [System.Xml.Serialization.XmlAttributeAttribute("batch-number-attr", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string BatchNumberAttribute;

        [System.Xml.Serialization.XmlAttributeAttribute("coverholder-number-attr", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string CoverHolderNumber;

        [System.Xml.Serialization.XmlElementAttribute("policy-transaction", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<PolicyTransaction> PolicyTransactionItems;

        [System.Xml.Serialization.XmlAttributeAttribute("schemaLocation", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string SchemaLocation = "http://www.lloydscanada.com/xsd/policy/PolicyUpload_1.xsd";

        [System.Xml.Serialization.XmlAttributeAttribute("namespace", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string Namespace = "http://www.lloydscanada.com/xsd/policy";

    }

    public class PolicyTransaction
    {
        [System.Xml.Serialization.XmlAttributeAttribute("transaction-number-attr", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string TransactionNumberAttribute;

        [System.Xml.Serialization.XmlElementAttribute("policy-create-transaction", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PolicyNewTransaction PolicyCreateNewTransaction;

        [System.Xml.Serialization.XmlElementAttribute("policy-create-renew-transaction", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PolicyRenewTransaction PolicyCreateRenewTransaction;

    }

    public class PolicyNewTransaction
    {
        [System.Xml.Serialization.XmlElementAttribute("policy-comm-create-record", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PolicyCommercialRecord PolicyCommercialCreateRecord;
    }

    public class PolicyRenewTransaction
    {
        [System.Xml.Serialization.XmlElementAttribute("policy-comm-create-record", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PolicyCommercialRecord PolicyCommercialCreateRecord;
    }

    public class PolicyCommercialRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("policy-number", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PolicyNumberField PolicyNumber;

        [System.Xml.Serialization.XmlElementAttribute("effective-date", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public EffectiveDateField EffectiveDate;

        [System.Xml.Serialization.XmlElementAttribute("expiry-date", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ExpiryDateField ExpiryDate;

        [System.Xml.Serialization.XmlElementAttribute("binder-flag", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public BinderFlagField BinderFlag;

        [System.Xml.Serialization.XmlElementAttribute("subscription-type-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public SubscriptionTypeCodeField SubscriptionTypeCode;

        [System.Xml.Serialization.XmlElementAttribute("total-premium-amount", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public TotalPremiumAmountField TotalPremiumAmount;

        [System.Xml.Serialization.XmlElementAttribute("payment-method-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PaymentMethodCodeField PaymentMethodCode;

        [System.Xml.Serialization.XmlElementAttribute("analysis-description-ref", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AnalysisDescriptionRefField AnalysisDescriptionRef;

        [System.Xml.Serialization.XmlElementAttribute("binding-authority-contract-nbr", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public BindingAuthorityContractNbrField BindingAuthorityContractNbr;

        [System.Xml.Serialization.XmlElementAttribute("coverage-list-type-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CoverageListTypeCodeField CoverageListTypeCode;

        [System.Xml.Serialization.XmlElementAttribute("insured-units-comm-create", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public InsuredCommercialUnitsRecord InsuredCommercialUnits;

        [System.Xml.Serialization.XmlElementAttribute("policy-parties", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PolicyPartiesRecord PolicyParties;

    }

    [System.Xml.Serialization.XmlTypeAttribute(TypeName = "policy-number")]
    public class PolicyNumberField
    {
        public string value;
    }

    public class EffectiveDateField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date")]
        public DateTime value;
    }

    public class ExpiryDateField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date")]
        public DateTime value;
    }

    public class BinderFlagField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string value;
    }

    public class SubscriptionTypeCodeField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string value;
    }

    public class TotalPremiumAmountField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public double value;
    }
    public class PaymentMethodCodeField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string value;
    }
    public class AnalysisDescriptionRefField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string value;
    }

    public class BindingAuthorityContractNbrField
    {
        public string value;
    }

    public class CoverageListTypeCodeField
    {
        public string value;
    }
    public class InsuredCommercialUnitsRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("insured-unit-comm-create-record", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<InsuredCommercialUnits> CommercialUnitsCreateRecord;
    }

    public class InsuredCommercialUnits
    {
        [System.Xml.Serialization.XmlElementAttribute("unit-number", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public UnitNumberField UnitNumber;

        [System.Xml.Serialization.XmlElementAttribute("effective-date", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public EffectiveDateField EffectiveDate;

        [System.Xml.Serialization.XmlElementAttribute("expiry-date", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ExpiryDateField ExpiryDate;

        [System.Xml.Serialization.XmlElementAttribute("insured-risk-name", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public InsuredRiskNameField InsuredRiskName;

        [System.Xml.Serialization.XmlElementAttribute("cholder-commission-schedule", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CHolderCommissionSchedule CommissionSchedule;

        [System.Xml.Serialization.XmlElementAttribute("address", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AddressRecord Address;

        [System.Xml.Serialization.XmlElementAttribute("industry-classification-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public IndustryClassificationCodeField IndustryClassificationCode;

        [System.Xml.Serialization.XmlElementAttribute("year-built", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public YearBuiltField YearBuilt;

        [System.Xml.Serialization.XmlElementAttribute("construction", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ConstructionField Construction;

        [System.Xml.Serialization.XmlElementAttribute("sprinklered", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public SprinkleredField Sprinklered;

        [System.Xml.Serialization.XmlElementAttribute("number-of-stories", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public NumberOfStoriesField NumberOfStories;

        [System.Xml.Serialization.XmlElementAttribute("is-earthquake-covered", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public IsEarthquakeCoveredField IsEarthquakeCovered;

        [System.Xml.Serialization.XmlElementAttribute("is-flood-covered", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public IsFloodCoveredField IsFloodCovered;

        [System.Xml.Serialization.XmlElementAttribute("coverages-comm-create", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CommercialCoveragesRecord CommercialCoverage;
    }

    public class UnitNumberField
    {
        public string value;
    }

    public class InsuredRiskNameField
    {
        public string value;
    }

    public class CHolderCommissionSchedule
    {
        [System.Xml.Serialization.XmlElementAttribute("cholder-commission", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<CHolderCommission> HolderCommission;
    }

    public class CHolderCommission
    {

        [System.Xml.Serialization.XmlElementAttribute("binding-authority-contract-nbr", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public BindingAuthorityContractNbrField BindingAuthorityContractNbr;

        [System.Xml.Serialization.XmlElementAttribute("analysis-description-ref", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AnalysisDescriptionRefField AnalysisDescriptionRef;

        [System.Xml.Serialization.XmlElementAttribute("cholder-commission-percent", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CHolderCommissionPercentField CHolderCommissionPercent;
    }

    public class CHolderCommissionPercentField
    {
        public string value;
    }

    public class AddressRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("country-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CountryCodeField CountryCode;

        [System.Xml.Serialization.XmlElementAttribute("address-line-1", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AddressLine1Field AddressLine1;

        [System.Xml.Serialization.XmlElementAttribute("address-line-2", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AddressLine2Field AddressLine2;

        [System.Xml.Serialization.XmlElementAttribute("city", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CityField City;

        [System.Xml.Serialization.XmlElementAttribute("postal-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PostalCodeField PostalCode;

        [System.Xml.Serialization.XmlElementAttribute("province-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ProvinceCodeField ProvinceCode;
    }

    public class IndustryClassificationCodeField
    {
        public string value;
    }

    public class YearBuiltField
    {
        public int value;
    }
    public class ConstructionField
    {
        public string value;
    }
    public class SprinkleredField
    {
        public string value;
    }
    public class NumberOfStoriesField
    {
        // This is integer in XSD validator
        public double value;
    }
    public class IsEarthquakeCoveredField
    {
        public string value;
    }
    public class IsFloodCoveredField
    {
        public string value;
    }

    public class CountryCodeField
    {
        public string value;
    }
    public class AddressLine1Field
    {
        public string value;
    }
    public class AddressLine2Field
    {
        public string value;
    }
    public class CityField
    {
        public string value;
    }
    public class PostalCodeField
    {
        public string value;
    }
    public class ProvinceCodeField
    {
        public string value;
    }

    public class CommercialCoveragesRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("coverage-comm-create-record", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<CommercialCoverageRecord> CommercialCoverages;
    }

    public class CommercialCoverageRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("coverage-type-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CoverageTypeField CoverageType;

        [System.Xml.Serialization.XmlElementAttribute("effective-date", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public EffectiveDateField EffectiveDate;

        [System.Xml.Serialization.XmlElementAttribute("expiry-date", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ExpiryDateField ExpiryDate;

        [System.Xml.Serialization.XmlElementAttribute("deductible-type-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public DeductibleTypeField DeductibleType;

        [System.Xml.Serialization.XmlElementAttribute("deductible-amount", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public DeductibleAmountField DeductibleAmount;

        [System.Xml.Serialization.XmlElementAttribute("premium-amount", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PremiumAmountField PremiumAmount;

        [System.Xml.Serialization.XmlElementAttribute("premium-participation-schedule", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PremiumParticipationScheduleRecord PremiumParticipationSchedule;

        [System.Xml.Serialization.XmlElementAttribute("claims-made-coverage-flag", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ClaimsMadeCoverageFlagField ClaimsMadeCoverageFlag;

        [System.Xml.Serialization.XmlElementAttribute("extended-report-period-flag", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ExtendedReportPeriodFlagField ExtendedReportPeriodFlag;

        [System.Xml.Serialization.XmlElementAttribute("retroactive-date", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public RetroactiveDateField RetroactiveDate;

        [System.Xml.Serialization.XmlElementAttribute("exposure-type-code", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ExposureTypeCodeField ExposureTypeCode;

        [System.Xml.Serialization.XmlElementAttribute("total-exposure-amount", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public TotalExposureAmountField TotalExposureAmount;

        [System.Xml.Serialization.XmlElementAttribute("coverage-limit", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CoverageLimitField CoverageLimit;

        [System.Xml.Serialization.XmlElementAttribute("turnover-or-fees", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public TurnOverOrFeesField TurnOverOrFees;

        [System.Xml.Serialization.XmlElementAttribute("occupation", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public OccupationField Occupation;

    }

    public class PremiumParticipationScheduleRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("premium-participation", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<PremiumParticipationRecord> PremiumParticipationRecords;

        [System.Xml.Serialization.XmlElementAttribute("other-premium-participation", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public List<OtherPremiumParticipationRecord> OtherPremiumParticipationRecords;

    }

    public class PremiumParticipationRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("binding-authority-contract-nbr", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public BindingAuthorityContractNbrField BindingAuthorityContractNbr;

        [System.Xml.Serialization.XmlElementAttribute("analysis-description-ref", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AnalysisDescriptionRefField AnalysisDescriptionRef;

        [System.Xml.Serialization.XmlElementAttribute("participation-percent", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ParticipationPercentField ParticipationPercent;

        [System.Xml.Serialization.XmlElementAttribute("premium-participation-amount", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PremiumParticipationAmountField PremiumParticipationAmount;
    }

    public class OtherPremiumParticipationRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("participation-percent", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public OtherParticipationPercentField OtherParticipationPercent;

        [System.Xml.Serialization.XmlElementAttribute("premium-participation-amount", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public OtherPremiumParticipationAmountField OtherPremiumParticipationAmount;
    }

    public class PolicyPartiesRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("policy-party", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PolicyPartyRecord PolicyParty;
    }

    public class PolicyPartyRecord
    {
        [System.Xml.Serialization.XmlAttributeAttribute("party-role-type-code-attr", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string PartyRoleTypeCodeAttr;

        [System.Xml.Serialization.XmlElementAttribute("company", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CompanyRecord Company;

    }

    public class CompanyRecord
    {
        [System.Xml.Serialization.XmlElementAttribute("name", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CompanyNameField CompanyName;

        [System.Xml.Serialization.XmlElementAttribute("address", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AddressRecord Address;
    }

    public class CompanyNameField
    {
        public string value;
    }

    public class CoverageTypeField
    {
        public string value;
    }
    public class DeductibleTypeField
    {
        public string value;
    }
    public class DeductibleAmountField
    {
        public double value;
    }
    public class PremiumAmountField
    {
        public double value;
    }

    public class ParticipationPercentField
    {
        public double value;
    }
    public class PremiumParticipationAmountField
    {
        public double value;
    }

    public class OtherParticipationPercentField
    {
        public double value;
    }
    public class OtherPremiumParticipationAmountField
    {
        public double value;
    }

    public class ClaimsMadeCoverageFlagField
    {
        public string value;
    }

    public class ExtendedReportPeriodFlagField
    {
        public string value;
    }

    public class RetroactiveDateField
    {
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date")]
        public DateTime value;
    }
    public class ExposureTypeCodeField
    {
        public string value;
    }

    public class TotalExposureAmountField
    {
        public double value;
    }
    public class CoverageLimitField
    {
        public double value;
    }
    public class TurnOverOrFeesField
    {
        public double value;
    }

    public class OccupationField
    {
        public string value;
    }

    internal static class PaymentMethod
    {
        public static Dictionary<string, string> PayMethodDesc = new Dictionary<string, string>()
        {
            { "A", "AGENCY_BILL" },
            { "D", "INSTALLMENT" },
            { "O", "PPP"}
        };
    }

}
