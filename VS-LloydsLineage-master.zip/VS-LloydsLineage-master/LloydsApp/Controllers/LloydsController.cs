﻿using LloydsXMLProperty;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Configuration;
using System.Xml;

namespace LloydsApp.Controllers
{
    public class LloydsController : ApiController
    {

        [HttpGet]
        [ActionName("CreateBatchApp")]
        public IHttpActionResult GenerateLloydsXMLBatch(string QueryCriteria)
        {
            string ptx = string.Empty;

            LloydsDataService.DataService svc = new LloydsDataService.DataService();
            LloydsDataService.Processor ds = new LloydsDataService.Processor();

            string XMLFilePath = WebConfigurationManager.AppSettings["XMLFilePath"];
            string FTPServerPath = WebConfigurationManager.AppSettings["FTPServerPath"];
            string SchemaFile = WebConfigurationManager.AppSettings["SchemaFile"];

            string[] param = QueryCriteria.Split('-');
            string XMLFile = "Lloyds" + "-" +  param[7] + "-" + param[6] + "-" + param[0] + ".xml";

            string XMLFileName = Path.Combine(XMLFilePath, XMLFile);
            string FTPFilePath = FTPServerPath + "/" + XMLFile;
            string WebMessage = string.Empty;

            ptx = ds.GenerateLloydsBatchApp(QueryCriteria);
            string CheckFile = svc.ValidateXML(ptx, SchemaFile);

            if (CheckFile == "OK")
            {
                WebMessage = "<div style='font-family: verdana'><a href='" + FTPFilePath + "'>Download policy " + XMLFile + "</ftp></div>";
                using (StreamWriter OutputFile = new StreamWriter(XMLFileName))
                {
                    OutputFile.Write(ptx);
                }
            }
            else
            {
                WebMessage = "<div style='font-family: verdana;color: red'>" + CheckFile + "</div>";
            }

            return base.ResponseMessage(new HttpResponseMessage()
            {
                Content = new StringContent(
                    WebMessage,
                    Encoding.UTF8,
                    "text/html"
                )
            });

        }

        [HttpGet]
        [ActionName("CreateSingleApp")]
        public IHttpActionResult GenerateLloydsXMLSingle(string QueryCriteria)
        {
            string ptx = string.Empty;

            LloydsDataService.DataService svc = new LloydsDataService.DataService();
            LloydsDataService.Processor ds = new LloydsDataService.Processor();

            string XMLFilePath = WebConfigurationManager.AppSettings["XMLFilePath"];
            string FTPServerPath = WebConfigurationManager.AppSettings["FTPServerPath"];
            string SchemaFile = WebConfigurationManager.AppSettings["SchemaFile"];

            string[] param = QueryCriteria.Split('-');
            string XMLFile = "Lloyds" + "-" + param[1] + "-" + param[2] + ".xml";

            string XMLFileName = Path.Combine(XMLFilePath, XMLFile);
            string FTPFilePath = FTPServerPath + "/" + XMLFile;
            string WebMessage = string.Empty;

            ptx = ds.GenerateLloydsSingleApp(QueryCriteria);
            string CheckFile = svc.ValidateXML(ptx, SchemaFile);

            if (CheckFile == "OK")
            {
                WebMessage = "<div style='font-family: verdana'><a href='" + FTPFilePath + "'>Download policy " + XMLFile + "</ftp></div>";
                using (StreamWriter OutputFile = new StreamWriter(XMLFileName))
                {
                    OutputFile.Write(ptx);
                }
            }
            else
            {
                WebMessage = "<div style='font-family: verdana;color: red'>" + CheckFile + "</div>";
            }

            return base.ResponseMessage(new HttpResponseMessage()
            {
                Content = new StringContent(
                    WebMessage,
                    Encoding.UTF8,
                    "text/html"
                )
            });
        }
    }
}
